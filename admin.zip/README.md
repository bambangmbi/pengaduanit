# Sistem Informasi Pengaduan Kerusakan Barang berbasis Web

Template by: AdminLTE

Langkah setup:
1. Download repo, lalu ekstrak ke folder htdocs yang ada didalam XAMPP
2. Import database terlebih dahulu, nama database harus sama dengan yang ada didalam folder db
3. Default user untuk login ke dalam admin panel:
    - username: admin
    - password: admin
